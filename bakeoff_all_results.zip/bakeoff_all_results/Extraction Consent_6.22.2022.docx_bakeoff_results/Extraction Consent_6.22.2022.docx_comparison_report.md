# Bake-Off Report for `Extraction Consent_6.22.2022.docx.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **unstructured** | 2.71 | 413 | 66.98 | `Extraction Consent_6.22.2022.docx_unstructured.txt` |
| **pdfplumber** | 0.09 | 411 | 76.65 | `Extraction Consent_6.22.2022.docx_pdfplumber.txt` |
| **ocrmypdf** | 6.45 | 403 | 73.14 | `Extraction Consent_6.22.2022.docx_ocrmypdf.txt` |
| **tesseract** | 1.17 | 403 | 49.68 | `Extraction Consent_6.22.2022.docx_tesseract.txt` |
| **doctr** | 6.27 | 400 | 62.24 | `Extraction Consent_6.22.2022.docx_doctr.txt` |
| **easyocr** | 5.47 | 393 | 146.11 | `Extraction Consent_6.22.2022.docx_easyocr.txt` |
