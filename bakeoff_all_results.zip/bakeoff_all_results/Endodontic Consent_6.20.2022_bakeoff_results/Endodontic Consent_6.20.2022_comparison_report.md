# Bake-Off Report for `Endodontic Consent_6.20.2022.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **unstructured** | 2.61 | 403 | 73.26 | `Endodontic Consent_6.20.2022_unstructured.txt` |
| **pdfplumber** | 0.09 | 401 | 78.11 | `Endodontic Consent_6.20.2022_pdfplumber.txt` |
| **ocrmypdf** | 6.37 | 394 | 74.57 | `Endodontic Consent_6.20.2022_ocrmypdf.txt` |
| **tesseract** | 1.15 | 393 | 53.24 | `Endodontic Consent_6.20.2022_tesseract.txt` |
| **doctr** | 6.36 | 390 | 63.22 | `Endodontic Consent_6.20.2022_doctr.txt` |
| **easyocr** | 5.10 | 389 | 174.13 | `Endodontic Consent_6.20.2022_easyocr.txt` |
