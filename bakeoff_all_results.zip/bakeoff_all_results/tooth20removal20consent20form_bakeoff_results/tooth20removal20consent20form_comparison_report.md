# Bake-Off Report for `tooth20removal20consent20form.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.02 | 269 | 63.78 | `tooth20removal20consent20form_pdfplumber.txt` |
| **ocrmypdf** | 2.60 | 261 | 61.00 | `tooth20removal20consent20form_ocrmypdf.txt` |
| **tesseract** | 0.81 | 260 | 39.17 | `tooth20removal20consent20form_tesseract.txt` |
| **easyocr** | 4.33 | 258 | 237.71 | `tooth20removal20consent20form_easyocr.txt` |
| **unstructured** | 2.06 | 255 | 58.59 | `tooth20removal20consent20form_unstructured.txt` |
| **doctr** | 4.76 | 254 | 60.33 | `tooth20removal20consent20form_doctr.txt` |
