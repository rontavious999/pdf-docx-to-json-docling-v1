# Bake-Off Report for `Gingivectomy Consent_6.23.2022.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.08 | 340 | 78.55 | `Gingivectomy Consent_6.23.2022_pdfplumber.txt` |
| **ocrmypdf** | 6.10 | 340 | 74.93 | `Gingivectomy Consent_6.23.2022_ocrmypdf.txt` |
| **tesseract** | 1.07 | 340 | 54.83 | `Gingivectomy Consent_6.23.2022_tesseract.txt` |
| **doctr** | 5.66 | 337 | 61.94 | `Gingivectomy Consent_6.23.2022_doctr.txt` |
| **unstructured** | 2.77 | 336 | 81.90 | `Gingivectomy Consent_6.23.2022_unstructured.txt` |
| **easyocr** | 5.44 | 334 | 124.56 | `Gingivectomy Consent_6.23.2022_easyocr.txt` |
