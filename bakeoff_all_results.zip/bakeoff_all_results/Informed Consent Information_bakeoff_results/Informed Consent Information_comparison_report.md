# Bake-Off Report for `Informed Consent Information.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **ocrmypdf** | 6.98 | 1043 | 70.87 | `Informed Consent Information_ocrmypdf.txt` |
| **easyocr** | 10.06 | 1035 | 278.88 | `Informed Consent Information_easyocr.txt` |
| **pdfplumber** | 0.08 | 1032 | 70.78 | `Informed Consent Information_pdfplumber.txt` |
| **tesseract** | 2.98 | 1032 | 53.22 | `Informed Consent Information_tesseract.txt` |
| **doctr** | 15.07 | 1029 | 69.32 | `Informed Consent Information_doctr.txt` |
| **unstructured** | 6.64 | 1020 | 117.04 | `Informed Consent Information_unstructured.txt` |
