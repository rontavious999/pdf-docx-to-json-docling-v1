# Bake-Off Report for `npf.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **tesseract** | 2.46 | 954 | 46.56 | `npf_tesseract.txt` |
| **unstructured** | 4.95 | 948 | 146.41 | `npf_unstructured.txt` |
| **ocrmypdf** | 7.80 | 946 | 58.64 | `npf_ocrmypdf.txt` |
| **doctr** | 12.49 | 946 | 41.46 | `npf_doctr.txt` |
| **pdfplumber** | 0.11 | 941 | 88.85 | `npf_pdfplumber.txt` |
| **easyocr** | 8.69 | 934 | 78.46 | `npf_easyocr.txt` |
