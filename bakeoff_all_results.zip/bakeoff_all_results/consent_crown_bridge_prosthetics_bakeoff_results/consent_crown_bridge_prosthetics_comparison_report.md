# Bake-Off Report for `consent_crown_bridge_prosthetics.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.09 | 836 | 73.28 | `consent_crown_bridge_prosthetics_pdfplumber.txt` |
| **unstructured** | 5.12 | 828 | 82.18 | `consent_crown_bridge_prosthetics_unstructured.txt` |
| **tesseract** | 2.29 | 828 | 54.39 | `consent_crown_bridge_prosthetics_tesseract.txt` |
| **easyocr** | 8.40 | 818 | 273.79 | `consent_crown_bridge_prosthetics_easyocr.txt` |
| **doctr** | 13.86 | 814 | 66.70 | `consent_crown_bridge_prosthetics_doctr.txt` |
| **ocrmypdf** | 6.06 | 813 | 67.07 | `consent_crown_bridge_prosthetics_ocrmypdf.txt` |
