# Bake-Off Report for `npf1.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.12 | 1038 | 45.45 | `npf1_pdfplumber.txt` |
| **unstructured** | 4.83 | 1013 | 43.26 | `npf1_unstructured.txt` |
| **ocrmypdf** | 5.29 | 908 | 35.97 | `npf1_ocrmypdf.txt` |
| **tesseract** | 2.45 | 833 | 35.97 | `npf1_tesseract.txt` |
| **doctr** | 11.27 | 796 | 22.84 | `npf1_doctr.txt` |
| **easyocr** | 10.77 | 783 | 104.92 | `npf1_easyocr.txt` |
