# Bake-Off Report for `CFGingivectomy.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.06 | 719 | 82.56 | `CFGingivectomy_pdfplumber.txt` |
| **ocrmypdf** | 7.06 | 717 | 80.52 | `CFGingivectomy_ocrmypdf.txt` |
| **tesseract** | 1.76 | 717 | 58.74 | `CFGingivectomy_tesseract.txt` |
| **unstructured** | 3.17 | 714 | 64.67 | `CFGingivectomy_unstructured.txt` |
| **doctr** | 9.73 | 705 | 78.53 | `CFGingivectomy_doctr.txt` |
| **easyocr** | 6.73 | 691 | 869.20 | `CFGingivectomy_easyocr.txt` |
