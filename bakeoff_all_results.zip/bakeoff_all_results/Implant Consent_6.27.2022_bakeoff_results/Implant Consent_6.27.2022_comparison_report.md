# Bake-Off Report for `Implant Consent_6.27.2022.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **unstructured** | 4.79 | 748 | 86.73 | `Implant Consent_6.27.2022_unstructured.txt` |
| **pdfplumber** | 0.16 | 748 | 85.24 | `Implant Consent_6.27.2022_pdfplumber.txt` |
| **ocrmypdf** | 8.67 | 748 | 83.48 | `Implant Consent_6.27.2022_ocrmypdf.txt` |
| **tesseract** | 2.29 | 748 | 61.29 | `Implant Consent_6.27.2022_tesseract.txt` |
| **doctr** | 10.69 | 741 | 70.76 | `Implant Consent_6.27.2022_doctr.txt` |
| **easyocr** | 8.14 | 740 | 186.50 | `Implant Consent_6.27.2022_easyocr.txt` |
