# Bake-Off Report for `Chicago-Dental-Solutions_Form.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **unstructured** | 5.94 | 862 | 52.41 | `Chicago-Dental-Solutions_Form_unstructured.txt` |
| **pdfplumber** | 0.70 | 715 | 28.08 | `Chicago-Dental-Solutions_Form_pdfplumber.txt` |
| **easyocr** | 9.19 | 661 | 51.27 | `Chicago-Dental-Solutions_Form_easyocr.txt` |
| **ocrmypdf** | 9.23 | 653 | 31.63 | `Chicago-Dental-Solutions_Form_ocrmypdf.txt` |
| **tesseract** | 2.14 | 631 | 16.16 | `Chicago-Dental-Solutions_Form_tesseract.txt` |
| **doctr** | 11.05 | 622 | 22.90 | `Chicago-Dental-Solutions_Form_doctr.txt` |
