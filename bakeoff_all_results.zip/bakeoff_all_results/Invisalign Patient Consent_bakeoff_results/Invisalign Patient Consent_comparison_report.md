# Bake-Off Report for `Invisalign Patient Consent.pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **pdfplumber** | 0.39 | 1805 | 46.97 | `Invisalign Patient Consent_pdfplumber.txt` |
| **unstructured** | 11.25 | 1785 | 75.91 | `Invisalign Patient Consent_unstructured.txt` |
| **tesseract** | 4.92 | 1772 | 33.16 | `Invisalign Patient Consent_tesseract.txt` |
| **ocrmypdf** | 14.64 | 1771 | 46.76 | `Invisalign Patient Consent_ocrmypdf.txt` |
| **easyocr** | 17.07 | 1742 | 173.00 | `Invisalign Patient Consent_easyocr.txt` |
| **doctr** | 22.48 | 1741 | 45.96 | `Invisalign Patient Consent_doctr.txt` |
