# Bake-Off Report for `Scan_20251014 (3).pdf`

| Library | Execution Time (s) | Word Count | Avg. Line Length | Output File |
|---|---|---|---|---|
| **ocrmypdf** | 4.25 | 115 | 42.07 | `Scan_20251014 (3)_ocrmypdf.txt` |
| **tesseract** | 5.95 | 115 | 25.28 | `Scan_20251014 (3)_tesseract.txt` |
| **doctr** | 3.62 | 114 | 33.26 | `Scan_20251014 (3)_doctr.txt` |
| **easyocr** | 5.93 | 114 | 129.40 | `Scan_20251014 (3)_easyocr.txt` |
| **unstructured** | 10.50 | 111 | 41.47 | `Scan_20251014 (3)_unstructured.txt` |
| **pdfplumber** | 0.19 | 0 | 0.00 | `Scan_20251014 (3)_pdfplumber.txt` |
