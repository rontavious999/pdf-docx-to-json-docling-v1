"""
Modularized components of the docling_text_to_modento pipeline.
"""
