# PDF to JSON Converter with Docling for Dental Forms

This project is a powerful two-step pipeline that automates the conversion of dental patient forms (from PDF or `.docx` files) into a structured, Modento-compliant JSON format. It uses local document extraction libraries (PyMuPDF and python-docx) for text extraction and a sophisticated Python script to parse and structure the data.

## Features

- **Automated Two-Step Pipeline**: A single command orchestrates the entire workflow from PDF to JSON.
- **Local Text Extraction**: Uses PyMuPDF (for PDFs) and python-docx (for DOCX files) to extract text locally without requiring external APIs.
- **Intelligent Form Parsing**: The script intelligently identifies and parses various form elements like checkboxes, grids, repeating sections, and composite fields.
- **Data Normalization**: Cleans, normalizes, and structures the extracted data using a predefined form dictionary to ensure consistency.
- **Modento-Compliant Output**: Generates JSON files that are structured to be compatible with the Modento system.
- **Debug and Statistics**: Includes a debug mode for detailed logs and generates a `.stats.json` sidecar file for each conversion, providing insights into the process.

## How It Works

The conversion process is handled by a sequence of scripts orchestrated by `run_all.py`:

1.  **Text Extraction (`docling_extract.py`)**:
    - Scans the `documents/` directory for `.pdf` and `.docx` files.
    - Uses **PyMuPDF** (fitz) for PDF text extraction and **python-docx** for DOCX files.
    - Extracts text locally without requiring external APIs or internet connection.
    - Saves the extracted plain text into the `output/` directory.

2.  **JSON Conversion (`docling_text_to_modento.py`)**:
    - Reads the raw text files from the `output/` directory.
    - Applies a large set of rules and regular expressions to parse the text, identifying sections, questions, and options.
    - Matches the parsed fields against the `dental_form_dictionary.json` template to create a structured, standardized output.
    - Generates the final `.modento.json` files in the `JSONs/` directory.

### Directory Structure

```
.
├── documents/          # Input: Place your PDF and DOCX forms here
├── output/             # Intermediate: Extracted plain text files are stored here
├── JSONs/              # Output: Final structured JSON files are saved here
├── run_all.py          # Main script to run the entire pipeline
├── docling_extract.py  # Script for local text extraction
├── docling_text_to_modento.py # Script for parsing text and converting to JSON
└── dental_form_dictionary.json # Template for standardizing form fields
```

## Getting Started

Follow these steps to set up and run the project.

### Prerequisites

- Python 3.x
- `pip` for installing packages

### Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/rontavious999/pdf-docx-to-json-docling-v1.git
    cd pdf-docx-to-json-docling-v1
    ```

2.  **Install dependencies:**
    ```bash
    pip install pymupdf python-docx
    ```

3.  **Install OCR support (optional, for scanned PDFs):**
    ```bash
    pip install pytesseract pillow
    sudo apt-get install tesseract-ocr
    ```

### Usage

1.  **Add Documents**: Place your dental form files (`.pdf` or `.docx`) into the `documents/` directory.

2.  **Run the Pipeline**:
    Execute the main script from the root of the project directory.
    ```bash
    python3 run_all.py
    ```

3.  **Check the Output**: The final structured JSON files will be created in the `JSONs/` directory. Each output file will be named after the original input file (e.g., `PatientForm.pdf` -> `PatientForm.modento.json`).

To run the extraction and conversion steps separately:

```bash
# Step 1: Extract text from documents
python3 docling_extract.py --in documents --out output

# Step 1 (OCR is now automatic for scanned PDFs by default!)
# No flags needed - OCR will be used automatically when needed

# Step 1 (disable auto-OCR if you want to skip scanned PDFs):
python3 docling_extract.py --in documents --out output --no-auto-ocr

# Step 1 (force OCR for all PDFs, even with text):
python3 docling_extract.py --in documents --out output --force-ocr

# Step 1 (with parallel processing for large batches):
python3 docling_extract.py --in documents --out output --jobs 4

# Step 2: Convert text to JSON (with debug mode)
python3 docling_text_to_modento.py --in output --out JSONs --debug

# Step 2 (with parallel processing for large batches):
python3 docling_text_to_modento.py --in output --out JSONs --jobs 4
```

**Parallel Processing (Priority 6.1):**
- Use `--jobs N` to process N files in parallel (e.g., `--jobs 4` for 4 parallel processes)
- Use `--jobs -1` to automatically use all available CPU cores
- Parallel processing significantly speeds up large batches (50+ forms)
- Default is sequential processing (`--jobs 1`) for better debugging

*(Note: The `run_all.py` script runs both steps automatically and enables debug mode by default for the conversion step.)*

## Supported Form Types

This pipeline is designed to work with:

- **Digitally-created PDFs with embedded text layers** - Most modern PDF forms created by software (Word, Adobe, etc.)
- **DOCX files** - Microsoft Word documents and compatible formats
- **Common dental intake form layouts** - Patient information, medical history, insurance, consent forms

The parser uses intelligent pattern matching to handle various form layouts without requiring form-specific customization.

## Known Limitations

While the pipeline achieves 95%+ field capture accuracy on most forms, there are some current limitations:

### Text Extraction
- **Automatic OCR for scanned PDFs**: ✓ **Now enabled by default** - The pipeline automatically detects PDFs without text layers and uses OCR when needed. No manual flag required! To disable this behavior, use `--no-auto-ocr`. Install OCR dependencies with: `pip install pytesseract pillow` and `sudo apt-get install tesseract-ocr`.
  - Use `--ocr` to force OCR fallback even for PDFs with text (legacy option)
  - Use `--force-ocr` to force OCR for all PDFs regardless of text layer
  - Use `--no-auto-ocr` to disable automatic OCR detection

### Edge Cases in Parsing
Most common edge cases are now handled automatically:
- **Multi-sub-field labels**: ✓ **Now supported** - Fields like "Phone: Mobile ___ Home ___ Work ___" are automatically split into separate phone_mobile, phone_home, and phone_work fields.
- **Grid column headers**: ✓ **Now supported** - In multi-column checkbox grids, category headers (e.g., "Appearance / Function / Habits") are now captured and prefixed to option names (e.g., "Habits - Smoking").
- **Inline checkboxes**: ✓ **Now supported** - Checkboxes embedded within sentences (e.g., "[ ] Yes, send me text alerts") are now captured as separate boolean fields with meaningful labels.

These edge cases affect less than 5% of fields on typical forms and are documented in `ACTIONABLE_ITEMS.md` for future improvement.

## Best Practices

For optimal results:

- ✅ **Use fillable PDFs when possible** - Forms created with form fields have the most consistent structure
- ✅ **Ensure PDFs have embedded text** - Test by trying to select and copy text from the PDF
- ✅ **Follow common form conventions** - Standard layouts with clear labels, checkboxes, and sections work best
- ✅ **Test with debug mode** - Use `--debug` flag to see detailed parsing logs and field statistics
- ✅ **Review the stats.json output** - Check the generated `.stats.json` files to verify field capture accuracy

## Testing

The project includes a comprehensive test suite to ensure reliability and catch regressions.

### Running Tests

```bash
# Run all tests
pytest tests/

# Run with verbose output
pytest tests/ -v

# Run a specific test file
pytest tests/test_text_preprocessing.py -v

# Run with coverage report (requires pytest-cov)
pip install pytest-cov
pytest tests/ --cov=docling_text_to_modento --cov-report=term-missing
```

### Test Coverage

The test suite covers:
- **Text preprocessing**: Line coalescing, normalization
- **Question parsing**: Field extraction, option cleaning, splitting
- **Template matching**: Catalog loading, fuzzy matching, aliases
- **Pattern recognition**: Dates, states, checkboxes, Yes/No questions

See `tests/README.md` for detailed documentation on the test suite.
