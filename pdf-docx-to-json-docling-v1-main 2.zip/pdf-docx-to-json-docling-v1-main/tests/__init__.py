"""
Unit tests for PDF-to-JSON Docling pipeline.

This test suite covers critical parsing functions to ensure reliability
and catch regressions when making changes to the codebase.
"""
