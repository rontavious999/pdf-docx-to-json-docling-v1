"""
Unit tests for question parsing functions.

Tests field extraction, splitting, and option cleaning logic.
"""

import sys
from pathlib import Path

# Add parent directory to path so we can import the main module
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import from core (these functions haven't been extracted yet)
from docling_text_to_modento.core import (
    clean_option_text,
    split_multi_question_line,
)


class TestCleanOptionText:
    """Test option text cleaning logic."""
    
    def test_removes_duplicate_words(self):
        """Consecutive duplicate words should be removed."""
        text = "Blood Blood Transfusion"
        result = clean_option_text(text)
        assert result == "Blood Transfusion"
    
    def test_removes_multiple_duplicates(self):
        """Multiple consecutive duplicates should all be removed."""
        text = "Heart Heart Heart Disease"
        result = clean_option_text(text)
        assert result == "Heart Disease"
    
    def test_preserves_valid_compounds_with_slash(self):
        """Valid compound phrases with slash should be preserved."""
        # Test common valid compounds
        assert "live/work" in clean_option_text("I live/work in area").lower()
        assert "AIDS/HIV" in clean_option_text("AIDS/HIV Positive")
        assert "/" in clean_option_text("Cold Sores/Fever Blisters")
    
    def test_cleans_malformed_slash_text(self):
        """Malformed slash-separated text should be cleaned."""
        # When second part is messy with multiple words and bad formatting
        text = "Epilepsy/ Excessive Seizers Bleeding Problems"
        result = clean_option_text(text)
        # Should take just the first part when second part is clearly malformed
        assert "Epilepsy" in result
        # The messy part might be removed or cleaned
    
    def test_corrects_ocr_typos(self):
        """Common OCR typos should be corrected."""
        text = "rregular Heartbeat"
        result = clean_option_text(text)
        assert "Irregular" in result or "rregular" not in result.lower()
    
    def test_preserves_clean_text(self):
        """Clean text should pass through unchanged."""
        text = "Diabetes"
        result = clean_option_text(text)
        assert result == "Diabetes"
    
    def test_handles_empty_text(self):
        """Empty or None text should be handled gracefully."""
        assert clean_option_text("") == ""
        assert clean_option_text(None) == None or clean_option_text(None) == ""
    
    def test_case_insensitive_duplicate_detection(self):
        """Duplicate detection should be case-insensitive."""
        text = "Blood blood transfusion"
        result = clean_option_text(text)
        assert result.count("blood") + result.count("Blood") == 1


class TestSplitMultiQuestionLine:
    """Test multi-question line splitting logic."""
    
    def test_splits_two_questions_with_spacing(self):
        """Two questions separated by multiple spaces should be split."""
        line = "Gender: [ ] Male [ ] Female     Marital Status: [ ] Married [ ] Single"
        result = split_multi_question_line(line)
        assert len(result) == 2
        assert "Gender:" in result[0]
        assert "Marital Status:" in result[1]
    
    def test_preserves_single_question(self):
        """Single question line should not be split."""
        line = "What is your name: ____________________"
        result = split_multi_question_line(line)
        assert len(result) == 1
        assert result[0] == line
    
    def test_splits_with_checkboxes(self):
        """Questions with checkboxes should split at proper boundaries."""
        line = "Insurance: [ ] Yes [ ] No    Phone: [ ] Mobile [ ] Home"
        result = split_multi_question_line(line)
        assert len(result) >= 1  # Should attempt to split
        # At least the line should still contain both fields
        full = " ".join(result)
        assert "Insurance:" in full
        assert "Phone:" in full
    
    def test_handles_line_without_split_points(self):
        """Line without clear split points should be returned as-is."""
        line = "First Name: __________ Last Name: __________"
        result = split_multi_question_line(line)
        # May or may not split depending on spacing, but should return valid list
        assert isinstance(result, list)
        assert len(result) >= 1


class TestFieldPatternMatching:
    """Test field label pattern matching."""
    
    def test_recognizes_date_fields(self):
        """Date field patterns should be recognized."""
        from docling_text_to_modento import DATE_LABEL_RE
        
        assert DATE_LABEL_RE.search("Date of Birth:")
        assert DATE_LABEL_RE.search("Birth Date:")
        assert DATE_LABEL_RE.search("DOB:")
        assert DATE_LABEL_RE.search("Date:")
    
    def test_recognizes_state_fields(self):
        """State field patterns should be recognized."""
        from docling_text_to_modento import STATE_LABEL_RE
        
        assert STATE_LABEL_RE.match("State:")
        assert STATE_LABEL_RE.match("State")
    
    def test_recognizes_checkbox_patterns(self):
        """Various checkbox formats should be recognized."""
        from docling_text_to_modento import CHECKBOX_ANY
        import re
        
        checkbox_re = re.compile(CHECKBOX_ANY)
        
        assert checkbox_re.search("[ ]")
        assert checkbox_re.search("[x]")
        assert checkbox_re.search("☐")
        assert checkbox_re.search("☑")
        assert checkbox_re.search("□")
        assert checkbox_re.search("✓")
        assert checkbox_re.search("✔")


class TestExtractCompoundYesNoPrompts:
    """Test Yes/No question extraction."""
    
    def test_extracts_simple_yes_no_question(self):
        """Simple Yes/No question should be extracted."""
        from docling_text_to_modento import extract_compound_yn_prompts
        
        line = "Are you pregnant? [ ] Yes [ ] No"
        result = extract_compound_yn_prompts(line)
        assert len(result) >= 1
        assert any("pregnant" in r.lower() for r in result)
    
    def test_extracts_question_with_continuation(self):
        """Yes/No question with continuation text should include it."""
        from docling_text_to_modento import extract_compound_yn_prompts
        
        line = "Do you smoke? [ ] Yes [ ] No If yes, how many per day?"
        result = extract_compound_yn_prompts(line)
        # Should extract the main question
        assert len(result) >= 1
    
    def test_handles_multiple_yes_no_in_line(self):
        """Multiple Yes/No questions in one line should be extracted."""
        from docling_text_to_modento import extract_compound_yn_prompts
        
        line = "Smoke? [ ] Yes [ ] No   Drink? [ ] Yes [ ] No"
        result = extract_compound_yn_prompts(line)
        # Should find at least one Yes/No pattern
        assert len(result) >= 1


class TestInlineCheckboxDetection:
    """Test inline checkbox with continuation text (Priority 2.3)."""
    
    def test_detects_yes_with_continuation(self):
        """Checkbox with Yes and continuation text should be detected."""
        from docling_text_to_modento import detect_inline_checkbox_with_text
        
        line = "[ ] Yes, send me text alerts"
        result = detect_inline_checkbox_with_text(line)
        assert result is not None
        key, title, field_type = result
        assert "yes" in title.lower()
        assert "text alerts" in title.lower()
        assert field_type == "radio"
    
    def test_detects_no_with_continuation(self):
        """Checkbox with No and continuation text should be detected."""
        from docling_text_to_modento import detect_inline_checkbox_with_text
        
        line = "[ ] No, I do not want to receive updates"
        result = detect_inline_checkbox_with_text(line)
        assert result is not None
        key, title, field_type = result
        assert "no" in title.lower()
        assert "updates" in title.lower()
    
    def test_ignores_short_continuation(self):
        """Checkbox with short continuation should be ignored."""
        from docling_text_to_modento import detect_inline_checkbox_with_text
        
        line = "[ ] Yes"
        result = detect_inline_checkbox_with_text(line)
        assert result is None
    
    def test_ignores_regular_text(self):
        """Regular text without checkbox should not be detected."""
        from docling_text_to_modento import detect_inline_checkbox_with_text
        
        line = "This is regular text"
        result = detect_inline_checkbox_with_text(line)
        assert result is None
    
    def test_generates_valid_key(self):
        """Generated key should be valid identifier."""
        from docling_text_to_modento import detect_inline_checkbox_with_text
        
        line = "[ ] Yes, please contact me about special offers"
        result = detect_inline_checkbox_with_text(line)
        assert result is not None
        key, _, _ = result
        # Key should be lowercase, use underscores, no spaces
        assert key.islower() or '_' in key
        assert ' ' not in key


class TestMultiFieldDetection:
    """Test multi-field label splitting (Priority 2.1)."""
    
    def test_detects_phone_multi_fields(self):
        """Phone fields with multiple sub-types should be detected."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Phone: Mobile _____ Home _____ Work _____"
        result = detect_multi_field_line(line)
        assert result is not None
        assert len(result) == 3
        assert any("mobile" in key for key, _ in result)
        assert any("home" in key for key, _ in result)
        assert any("work" in key for key, _ in result)
    
    def test_detects_email_multi_fields(self):
        """Email fields with multiple sub-types should be detected."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Email: Personal _____ Work _____"
        result = detect_multi_field_line(line)
        assert result is not None
        assert len(result) == 2
        assert any("personal" in key for key, _ in result)
        assert any("work" in key for key, _ in result)
    
    def test_detects_fields_with_spacing(self):
        """Fields separated by spaces should be detected."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Phone:    Mobile    Home    Work"
        result = detect_multi_field_line(line)
        assert result is not None
        assert len(result) == 3
    
    def test_ignores_single_field(self):
        """Single fields should not be detected as multi-field."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Name: First Last"
        result = detect_multi_field_line(line)
        assert result is None
    
    def test_ignores_phone_with_value(self):
        """Fields with actual values should not be detected."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Phone: (555) 123-4567"
        result = detect_multi_field_line(line)
        assert result is None
    
    def test_generates_proper_keys(self):
        """Generated keys should follow proper naming convention."""
        from docling_text_to_modento import detect_multi_field_line
        
        line = "Contact: Primary _____ Secondary _____"
        result = detect_multi_field_line(line)
        if result:
            for key, title in result:
                # Keys should be lowercase with underscores
                assert key.islower() or '_' in key
                assert ' ' not in key
                # Titles should be readable
                assert len(title) > 0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
